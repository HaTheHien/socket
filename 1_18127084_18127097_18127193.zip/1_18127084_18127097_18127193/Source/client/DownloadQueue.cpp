#include "DownloadQueue.h"

DownloadQueue::DownloadQueue()
{

}

DownloadQueue::DownloadQueue(QWidget *ui)
{
    this->ui_downloadTab = ui;
}
